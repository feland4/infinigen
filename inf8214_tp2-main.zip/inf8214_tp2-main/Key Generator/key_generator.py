import os
print(os.urandom(24).hex())
